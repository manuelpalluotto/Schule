import javax.swing.*;

public class GameFrame extends JFrame {
}
