import javax.swing.*;

public class Label extends JLabel {

    public Label(ImageIcon backgroundIcon) {
        setSize(1920, 1080);
        setVisible(true);
    }
}
