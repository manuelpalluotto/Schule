import javax.swing.*;

public class LoginFrame extends JFrame {

    public LoginFrame() {
        ImageIcon backgroundIcon = new ImageIcon("/emptyTTT.jpg");
        new Label(backgroundIcon);

        setVisible(false);
    }
}
